import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Automation SaaS | Premium Growth Engine",
  description: "AI automation dla nowoczesnych firm lokalnych i online. Agent AI do leadów, komunikacji i sprzedaży 24/7.",
  keywords: ["AI automation", "SaaS", "lead automation", "onboarding"],
  openGraph: { title: "AI Automation SaaS", description: "Premium AI automation subscription." }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="pl"><body>{children}</body></html>;
}
