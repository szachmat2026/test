import { Bot, Building2, ChartSpline, ClipboardCheck, HeartPulse, House, MessageCircleCode, Scale, Sparkles, Store } from "lucide-react";

export const navItems = ["Jak działa", "Funkcje", "Branże", "Cennik", "FAQ"];
export const stats = [
  { label: "średni wzrost leadów", value: "+47%" },
  { label: "odpowiedzi zautomatyzowane", value: "92%" },
  { label: "czas wdrożenia", value: "48h" }
];

export const steps = [
  { title: "Wybierz branżę", desc: "Dopasowujemy automatyzacje do Twojego modelu sprzedaży.", icon: Building2 },
  { title: "Onboarding AI", desc: "Konfigurujesz cele, tone-of-voice i priorytety obsługi.", icon: ClipboardCheck },
  { title: "AI działa za Ciebie", desc: "Agent obsługuje zapytania, follow-upy i lead routing 24/7.", icon: Bot }
];

export const features = ["AI chatbot","WhatsApp automation","AI follow-up","Automatyczne odpowiedzi","Lead qualification","Analytics","CRM sync","Dashboard","AI workflows","Reminders"];

export const industries = [
  { name: "Nieruchomości", icon: House },{ name: "Beauty", icon: Sparkles },{ name: "Gastronomia", icon: Store },{ name: "Ecommerce", icon: ChartSpline },{ name: "Medycyna", icon: HeartPulse },{ name: "Warsztaty", icon: MessageCircleCode },{ name: "Lokale usługowe", icon: Building2 },{ name: "Wynajem apartamentów", icon: House },{ name: "Kancelarie", icon: Scale },{ name: "Firmy lokalne", icon: Store }
];
