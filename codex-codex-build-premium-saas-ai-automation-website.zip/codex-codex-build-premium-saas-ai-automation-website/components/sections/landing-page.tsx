"use client";

import { motion } from "framer-motion";
import { Check, ChevronRight, Menu, Sparkles } from "lucide-react";
import { features, industries, navItems, stats, steps } from "@/lib/data";

const fade = { initial: { opacity: 0, y: 16 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true, amount: 0.2 }, transition: { duration: 0.5 } };

export function LandingPage() {
  return (
    <main>
      <header className="sticky top-0 z-50 border-b border-white/10 bg-[#05070f]/80 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2"><Sparkles className="h-5 w-5 text-cyan-300" /><span className="font-semibold">AIAutoOS</span></div>
          <nav className="hidden gap-8 text-sm text-muted md:flex">{navItems.map((n) => <a key={n} href={`#${n}`} className="hover:text-white">{n}</a>)}</nav>
          <button className="glass rounded-xl p-2 md:hidden"><Menu className="h-4 w-4" /></button>
        </div>
      </header>

      <section className="section pt-24">
        <motion.div {...fade} className="mb-6 inline-flex items-center gap-2 rounded-full border border-cyan-300/40 bg-cyan-300/10 px-4 py-2 text-sm">AI-powered automation</motion.div>
        <div className="grid gap-12 lg:grid-cols-2">
          <motion.div {...fade}><h1 className="text-4xl font-semibold leading-tight md:text-6xl">AI Automation dla nowoczesnych firm</h1><p className="mt-6 text-lg text-muted">Twój agent AI do obsługi klientów, leadów i follow-upów. Sprzedawaj szybciej, działaj automatycznie, skaluj bez chaosu.</p><div className="mt-8 flex gap-4"><button className="rounded-xl bg-white px-6 py-3 text-black">Rozpocznij onboarding</button><button className="glass rounded-xl px-6 py-3">Zobacz demo</button></div><div className="mt-10 grid grid-cols-3 gap-4">{stats.map((s) => <div key={s.label} className="glass rounded-2xl p-4"><p className="text-2xl font-semibold">{s.value}</p><p className="text-xs text-muted">{s.label}</p></div>)}</div></motion.div>
          <motion.div {...fade} className="glass animate-float rounded-3xl p-6"><div className="mb-4 flex items-center justify-between"><p>AI Control Center</p><span className="rounded-full bg-emerald-400/20 px-3 py-1 text-xs text-emerald-300">Active</span></div><div className="space-y-3">{["Nowy lead z formularza", "AI wysłał follow-up #2", "Klient potwierdził konsultację"].map((e) => <div key={e} className="rounded-xl bg-white/5 p-3 text-sm">{e}</div>)}</div><div className="mt-5 h-40 rounded-2xl bg-gradient-to-br from-indigo-500/30 via-cyan-400/20 to-fuchsia-500/20" /></motion.div>
        </div>
      </section>

      <section id="Jak działa" className="section"><h2 className="text-3xl font-semibold">Jak to działa</h2><div className="mt-10 grid gap-6 md:grid-cols-3">{steps.map((s, i) => <motion.article key={s.title} {...fade} className="glass rounded-2xl p-6"><s.icon className="mb-4 h-5 w-5 text-cyan-300"/><p className="mb-2 text-sm text-cyan-200">Krok {i+1}</p><h3 className="text-xl">{s.title}</h3><p className="mt-2 text-muted">{s.desc}</p></motion.article>)}</div></section>

      <section className="section grid gap-8 lg:grid-cols-2"><div className="glass rounded-3xl p-8"><h3 className="text-2xl">Problem</h3><ul className="mt-4 space-y-3 text-muted">{["Chaos komunikacji","Brak czasu","Utrata klientów","Brak follow-upów","Ręczne odpowiadanie"].map((i)=><li key={i}>• {i}</li>)}</ul></div><div className="glass rounded-3xl p-8"><h3 className="text-2xl">Rozwiązanie AI</h3><ul className="mt-4 space-y-3">{["Centralna skrzynka AI","Instant responses 24/7","Inteligentna kwalifikacja leadów","Auto follow-up pipelines","Workflow per branża"].map((i)=><li key={i} className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-300"/>{i}</li>)}</ul></div></section>

      <section id="Funkcje" className="section"><h2 className="text-3xl font-semibold">Funkcje premium</h2><div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-5">{features.map((f)=><div key={f} className="glass rounded-2xl p-4 text-sm transition hover:-translate-y-1 hover:border-cyan-300/40">{f}</div>)}</div></section>

      <section id="Branże" className="section"><h2 className="text-3xl font-semibold">Branże</h2><div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-5">{industries.map((ind)=><div key={ind.name} className="glass rounded-2xl p-5"><ind.icon className="h-5 w-5 text-cyan-300"/><h3 className="mt-3">{ind.name}</h3><p className="mt-2 text-sm text-muted">Dedykowane automatyzacje i AI flows.</p></div>)}</div></section>

      <section className="section"><div className="glass rounded-3xl p-8"><h2 className="text-3xl font-semibold">Dashboard Preview</h2><div className="mt-8 grid gap-4 md:grid-cols-4">{["Leady: 128", "Response time: 14s", "AI tasks: 94", "Conversion: 18.2%"].map((k)=><div key={k} className="rounded-xl bg-white/5 p-4">{k}</div>)}</div><div className="mt-6 h-56 rounded-2xl bg-gradient-to-r from-indigo-400/20 to-cyan-300/20" /></div></section>

      <section className="section"><h2 className="text-3xl font-semibold">Onboarding</h2><div className="mt-8 grid gap-6 lg:grid-cols-2"><div className="glass rounded-2xl p-6"><p className="text-sm text-muted">Krok 2/5</p><div className="mt-3 h-2 rounded-full bg-white/10"><div className="h-2 w-2/5 rounded-full bg-cyan-300"/></div><p className="mt-4">Konfiguracja AI + pytania dynamiczne</p></div><div className="glass rounded-2xl p-6">Workflow setup: Kanały, CRM, SLA, follow-up cadence.</div></div></section>

      <section id="Cennik" className="section"><h2 className="text-3xl font-semibold">Cennik</h2><div className="mt-4 inline-flex rounded-xl border border-white/15 p-1 text-sm"><button className="rounded-lg bg-white px-4 py-2 text-black">Monthly</button><button className="px-4 py-2">Yearly -20%</button></div><div className="mt-8 grid gap-6 md:grid-cols-3">{[["Starter","499 zł"],["Pro","1299 zł"],["Enterprise","Custom"]].map((p,idx)=><div key={p[0]} className={`rounded-2xl p-6 ${idx===1?"border-cyan-300/60 bg-cyan-300/10":"glass"}`}><h3 className="text-xl">{p[0]}</h3><p className="mt-2 text-3xl">{p[1]}</p><button className="mt-6 flex items-center gap-2">Wybierz plan <ChevronRight className="h-4 w-4"/></button></div>)}</div></section>

      <section className="section"><h2 className="text-3xl font-semibold">Opinie klientów</h2><div className="mt-8 grid gap-4 md:grid-cols-3">{["Wdrożenie w 2 dni, leady +52%.","AI przejął 80% odpowiedzi.","Najlepsza inwestycja operacyjna."].map((t)=><div key={t} className="glass rounded-2xl p-5">“{t}”</div>)}</div></section>

      <section id="FAQ" className="section"><h2 className="text-3xl font-semibold">FAQ</h2><div className="mt-8 space-y-4">{["Czy integrujecie CRM?","Ile trwa wdrożenie?","Czy mogę skalować użytkowników?"].map((q)=><details key={q} className="glass rounded-2xl p-5"><summary className="cursor-pointer">{q}</summary><p className="mt-2 text-muted">Tak, platforma jest gotowa do dalszej rozbudowy o logowanie, płatności i multi-tenant.</p></details>)}</div></section>

      <section className="section"><div className="glass rounded-3xl p-10 text-center"><h2 className="text-4xl font-semibold">Uruchom swojego agenta AI</h2><p className="mt-4 text-muted">Skaluj sprzedaż i obsługę klientów bez zwiększania zespołu.</p><button className="mt-8 rounded-xl bg-white px-6 py-3 text-black">Start teraz</button></div></section>

      <footer className="border-t border-white/10 py-10 text-center text-sm text-muted">© 2026 AIAutoOS · Premium AI SaaS Platform</footer>
    </main>
  );
}
