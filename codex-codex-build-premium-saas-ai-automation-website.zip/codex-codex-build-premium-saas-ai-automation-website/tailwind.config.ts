import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        background: "#05070f",
        foreground: "#f5f7ff",
        muted: "#9aa2c3",
        card: "#0f152a"
      },
      backgroundImage: {
        "radial-mesh": "radial-gradient(circle at 20% 20%, rgba(84,123,255,.30), transparent 40%), radial-gradient(circle at 80% 0%, rgba(0,244,197,.20), transparent 35%), radial-gradient(circle at 60% 70%, rgba(199,137,255,.25), transparent 40%)"
      },
      keyframes: {
        float: {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-8px)" }
        }
      },
      animation: {
        float: "float 6s ease-in-out infinite"
      }
    }
  },
  plugins: []
} satisfies Config;
